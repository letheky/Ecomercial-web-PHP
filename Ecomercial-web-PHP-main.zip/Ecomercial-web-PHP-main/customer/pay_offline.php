<center><!--  center Begin  -->
    
    <h1> Thanh toán ngoại tuyến bằng phương thức </h1>
    
    <p class="text-muted">
        
        Nếu bạn có bất kỳ câu hỏi nào, vui lòng <a href="../contact.php">Liên hệ</a>. Dịch vụ khách hàng của chúng tôi <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->


<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover table-striped"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
        <tr><!--  tr Begin  -->
            
            <th> Chi tiết tài khoản ngân hàng: </th>
            <th> Paypal, Easy Paisa, UBL: </th>
            <th> Chi tiết Western Union: </th>

        </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
           
           <td> Tên ngân hàng: UBL | Tài khoản số: 180-839-032 | Tên chi nhánh: Lahore | Mã chi nhánh: 1498 </td>
           <td> NIC #980-231-907 | Số điện thoại: 0931-7894-9983 | Tên: MrKC </td>
           <td> Tên thật: Lê Thế Kỷ | Số điện thoại: 0931-7894-9983 Quốc gia: VietNam | Tên: MrKC | NIC #980-231-907 </td>
            
        </tbody>
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->